from flask import Flask, render_template, request

app = Flask(__name__)

@app.route('/')
def Home():
    return render_template('index.html')

@app.route("/customer")
def customer():
    return render_template('customer.html')

@app.route("/employee")
def employee():
    return render_template('employee.html')

@app.route("/management")
def management():
    return render_template('management.html')

if __name__ == "__main__":
    app.run(debug=True) 



